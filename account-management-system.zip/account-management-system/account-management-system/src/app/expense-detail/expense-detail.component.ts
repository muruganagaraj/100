import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AddExpenseDetailComponent } from 'app/add-expense-detail/add-expense-detail.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ExpenseDetail } from 'model/expenseModel';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { TextPairHelperService } from '../services/text-pair-helper.service';
import { ViewModel, ItemViewmodel } from './expense-detail.viewmodel';
import { StorageHelper } from 'app/storage/storageHelper';
@Component({
  selector: 'app-expense-detail',
  templateUrl: './expense-detail.component.html',
  styleUrls: ['./expense-detail.component.scss']
})
export class ExpenseDetailComponent implements OnInit {
  expenseForm: FormGroup;
  maxDate = new Date();
  isGSTRequired: boolean;
  buyerList: TextPair[] = [];
  isExpensive: boolean = false;
  vm: ViewModel[] = [];
  totalAmount: number = 0;
  isAddDisabled: boolean = true;
  parentBuyerList: any[] = [];
  discount: number = 0;
  constructor(public dialog: MatDialog, private formBuilder: FormBuilder,
    private http: HttpClient,
    private textPairHelperService: TextPairHelperService,
    public storageHelper: StorageHelper) { }
  ngOnInit() {
    this.isGSTRequired = false;
    this.getBuyerList();
  }
  getBuyerList(): any {
    this.storageHelper.isBusy = true;
    const endpoint: string = 'https://cfztsaiwb1.execute-api.us-east-1.amazonaws.com/default/EDU_B_GETAll';
    this.http.get(endpoint).subscribe((item: any) => {
      this.storageHelper.isBusy = false;
      this.parentBuyerList = item;
      this.buyerList = this.textPairHelperService.createBuyerTextPair(item);
    });
  }
  getExpensiveData(value: any): void {
    console.log('make api call');
    const endpoint: string = 'https://73hm04j8hh.execute-api.us-east-1.amazonaws.com/default/EDU_Expense_Get';
    this.http.get(endpoint).subscribe((item: any) => {
      if (item.length > 0) {
        let data: any[] = item.filter(x => x.BuyerId === value);
        if (data.length > 0) {
          this.isExpensive = true;
          this.vm = this.getdata(data);
          for (let i: number = 0; i < this.vm.length; i++) {
            for (let j: number = 0; j < this.vm[i].items.length; j++) {
              this.totalAmount = this.totalAmount + this.vm[i].items[j].Amount;
            }
          }
          // here
        } else {
          this.isExpensive = false;
          alert('no data found for the buyer, please choose differenct buyer.');
        }
      } else {
        this.isExpensive = false;
        alert('no data found for the buyer, please choose differenct buyer.');
      }
    });
  }

  gstPercentage: number = 0;

  getGST(endpoint: any): any {
    //this.storageHelper.isBusy = true;
    return this.http.get(endpoint).subscribe(
      (res: any) => {
        let gstInfo = this.parentBuyerList.filter((x) => x.BuyerId === this.buyierId)[0];
        this.gstPercentage = res.filter(x => x.GSTId === gstInfo.GSTId)[0].GST;
        //this.storageHelper.isBusy = false;
      }
    )
  }

  toggleVisibility(e: any): void {
    this.isGSTRequired = e.checked;
  }


  getdata(expItem: any[]): ViewModel[] {
    return (expItem || []).map((item: any) => <ViewModel>{
      ExpenseId: item.ExpenseId,
      BuyerId: item.BuyerId,
      ExpenseDate: item.ExpenseDate,
      TotalItemAmount: item.TotalItemAmount,
      IsGSTRequired: item.IsGSTRequired,
      GST: item.GST,
      TotalAmountWithGST: item.TotalAmountWithGST,
      Discount: item.Discount,
      FinalAmount: item.FinalAmount,
      items: this.getItemData(item.Items)
    });
  }

  getItemData(list: any[]): ItemViewmodel[] {
    return (list || []).map((item: any) => <ItemViewmodel>{
      ExpenseId: item.ExpenseId,
      ItemId: item.ItemId,
      ItemCode: item.ItemCode,
      ItemName: item.ItemName,
      Quantity: item.Quantity,
      Amount: item.Amount
    });
  }

  public ExpensiceList: ItemViewmodel[] = [];


  openDialog(): void {
    const dialogRef = this.dialog.open(AddExpenseDetailComponent, {
      height: "auto",
      width: "auto",
      data: { undefined }
    });

    dialogRef.afterClosed().subscribe(result => {
      this.ExpensiceList.push(this.setExpensiveData(result));
      this.totalAmount = 0;
      for (let i: number = 0; i < this.ExpensiceList.length; i++) {
        this.totalAmount += +this.ExpensiceList[i].Amount;
      }
    });
  }

  setExpensiveData(item: any): ItemViewmodel {
    let data: ItemViewmodel = {};
    data.Amount = item.amount;
    data.ItemCode = item.itemId;
    data.ItemName = item.itemname;
    data.Quantity = item.quantity;
    data.ExpenseId = undefined;
    data.ItemId = undefined;
    return data;
  }

  buyierId: number = undefined;

  onChange(value: any): void {
    if (value) {
      this.buyierId = value;
      const endpoint = 'https://6d73py636l.execute-api.us-east-1.amazonaws.com/default/EDU_G_GetAll';
      this.getGST(endpoint);
    }
    this.isAddDisabled = value ? false : true;
  }

  onSubmit() {
    alert('Hi');
  }

  onDiscountChallenge(value: any): void {
    this.discount = value.target.value;
  }
}
